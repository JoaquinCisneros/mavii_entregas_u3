#include "Game.h"
#include "Box2DHelper.h"

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana de renderizado
    wnd = new RenderWindow(VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    SetZoom(); // Configuraci�n del zoom de la c�mara
    InitPhysics(); // Inicializaci�n del mundo f�sico
}

// M�todo principal que maneja el bucle del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpia la ventana con un color especificado
        DoEvents(); // Procesa los eventos del sistema
        UpdatePhysics(); // Actualiza la simulaci�n f�sica
        DrawGame(); // Dibuja el juego en la ventana
        wnd->display(); // Muestra la ventana renderizada
    }
}

// Actualiza la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Avanza la simulaci�n f�sica
    phyWorld->ClearForces(); // Limpia las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibuja el mundo f�sico (para depuraci�n)

}

// Dibuja los elementos del juego en la ventana
void Game::DrawGame()
{
    // Dibujamos el suelo
    sf::RectangleShape groundShape(sf::Vector2f(500, 5));
    groundShape.setFillColor(sf::Color::Red);
    groundShape.setPosition(0, 95);
    wnd->draw(groundShape);

    // Dibujamos las paredes
    sf::RectangleShape leftWallShape(sf::Vector2f(10, alto)); // Alto de la ventana
    leftWallShape.setFillColor(sf::Color::Red);
    leftWallShape.setPosition(100, 0); // X = 100 para que comience donde termina el suelo
    wnd->draw(leftWallShape);

    sf::RectangleShape rightWallShape(sf::Vector2f(10, alto)); // Alto de la ventana
    rightWallShape.setFillColor(sf::Color::Cyan);
    rightWallShape.setPosition(90, 0); // X = 90 para que comience donde termina el suelo
    wnd->draw(rightWallShape);

}

// Procesa los eventos del sistema
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cierra la ventana
            break;
        case Event::MouseButtonPressed:
            break;
        }
    }

}

// Configura el �rea visible en la ventana de renderizado
void Game::SetZoom()
{
    View camara;
    camara.setSize(100.0f, 100.0f); // Tama�o del �rea visible
    camara.setCenter(50.0f, 50.0f); // Centra la vista en estas coordenadas
    wnd->setView(camara); // Asigna la vista a la ventana
}

// Inicializa el mundo f�sico y los elementos est�ticos del juego
void Game::InitPhysics()
{
    // Inicializa el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    // Inicializa el renderizador de depuraci�n para el mundo f�sico

    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX); // Configura el renderizado para que muestre todo
    phyWorld->SetDebugDraw(debugRender);

    // Crea los elementos est�ticos del juego (suelo y paredes)

    b2Body* topWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 5);
    topWallBody->SetTransform(b2Vec2(50.0f, 0.0f), 0.0f);
    b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 5);
    groundBody->SetTransform(b2Vec2(50.0f, 100.0f), 0.0f);
    b2Body* leftWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 5, 100);
    leftWallBody->SetTransform(b2Vec2(0.0f, 50.0f), 0.0f);
    b2Body* rightWallBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 5, 100);
    rightWallBody->SetTransform(b2Vec2(100.0f, 50.0f), 0.0);

    //Plataforma estatica

    b2Body* staticPlatformBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 10, 3);
    staticPlatformBody->SetTransform(b2Vec2(50.0f, 50.0f), 0);

    //Pelotas

    ballBody1 = Box2DHelper::CreateCircularDynamicBody(phyWorld, 5.0f, 1.0f, 0.3f, 0.2f);
    ballBody1->SetTransform(b2Vec2(50.0f, 70.f), 0);
    

   //Joint para hacer la union

    b2Joint* ballJoint = Box2DHelper::CreateDistanceJoint(phyWorld, staticPlatformBody, b2Vec2(50.0f, 50.0f), ballBody1, b2Vec2(50.0f, 70.0f), 2.0f, 0.5f, 0.1f);

    //Impulso para dar movimiento inicial
    ballBody1->SetLinearVelocity(b2Vec2(30.0f, -20.0f));

}

